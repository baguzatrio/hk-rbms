import bookings from './bookings'
import rooms from './rooms'
import users from './users'
import organizations from './organizations'
import logs from './logs'
import display from './display'
const admin = {
    bookings: Object.assign(bookings, bookings),
rooms: Object.assign(rooms, rooms),
users: Object.assign(users, users),
organizations: Object.assign(organizations, organizations),
logs: Object.assign(logs, logs),
display: Object.assign(display, display),
}

export default admin
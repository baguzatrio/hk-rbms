
<template>
    <div
        class="flex aspect-square size-8 items-center justify-center rounded-md bg-white text-sidebar-primary-foreground">
        <img src="/images/logoHK.png" alt="Logo HK" class="object-contain size-6">
    </div>
    <div class="ml-1 grid flex-1 text-left text-sm">
        <span class="mb-0.5 truncate leading-tight font-semibold text-lg">RBMS</span>
    </div>
</template>

import BookingController from './BookingController'
import DashboardController from './DashboardController'
import Admin from './Admin'
import ScheduleController from './ScheduleController'
import RoomDisplayController from './RoomDisplayController'
import Settings from './Settings'
const Controllers = {
    BookingController: Object.assign(BookingController, BookingController),
DashboardController: Object.assign(DashboardController, DashboardController),
Admin: Object.assign(Admin, Admin),
ScheduleController: Object.assign(ScheduleController, ScheduleController),
RoomDisplayController: Object.assign(RoomDisplayController, RoomDisplayController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers
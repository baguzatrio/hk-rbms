import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
const index4c7472db58c32bd798169efd110569d5 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index4c7472db58c32bd798169efd110569d5.url(options),
    method: 'get',
})

index4c7472db58c32bd798169efd110569d5.definition = {
    methods: ["get","head"],
    url: '/api/admin/organizations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
index4c7472db58c32bd798169efd110569d5.url = (options?: RouteQueryOptions) => {
    return index4c7472db58c32bd798169efd110569d5.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
index4c7472db58c32bd798169efd110569d5.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index4c7472db58c32bd798169efd110569d5.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
index4c7472db58c32bd798169efd110569d5.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index4c7472db58c32bd798169efd110569d5.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
    const index4c7472db58c32bd798169efd110569d5Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index4c7472db58c32bd798169efd110569d5.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
        index4c7472db58c32bd798169efd110569d5Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index4c7472db58c32bd798169efd110569d5.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/api/admin/organizations'
 */
        index4c7472db58c32bd798169efd110569d5Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index4c7472db58c32bd798169efd110569d5.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index4c7472db58c32bd798169efd110569d5.form = index4c7472db58c32bd798169efd110569d5Form
    /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
const index49100f47f6a000f6cee2b47332dfc703 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index49100f47f6a000f6cee2b47332dfc703.url(options),
    method: 'get',
})

index49100f47f6a000f6cee2b47332dfc703.definition = {
    methods: ["get","head"],
    url: '/admin/organizations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
index49100f47f6a000f6cee2b47332dfc703.url = (options?: RouteQueryOptions) => {
    return index49100f47f6a000f6cee2b47332dfc703.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
index49100f47f6a000f6cee2b47332dfc703.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index49100f47f6a000f6cee2b47332dfc703.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
index49100f47f6a000f6cee2b47332dfc703.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index49100f47f6a000f6cee2b47332dfc703.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
    const index49100f47f6a000f6cee2b47332dfc703Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index49100f47f6a000f6cee2b47332dfc703.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
        index49100f47f6a000f6cee2b47332dfc703Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index49100f47f6a000f6cee2b47332dfc703.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\OrganizationController::index
 * @see app/Http/Controllers/Admin/OrganizationController.php:13
 * @route '/admin/organizations'
 */
        index49100f47f6a000f6cee2b47332dfc703Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index49100f47f6a000f6cee2b47332dfc703.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index49100f47f6a000f6cee2b47332dfc703.form = index49100f47f6a000f6cee2b47332dfc703Form

/**
* Multiple routes resolve to \App\Http\Controllers\Admin\OrganizationController::index, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `index['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const index = {
    '/api/admin/organizations': index4c7472db58c32bd798169efd110569d5,
    '/admin/organizations': index49100f47f6a000f6cee2b47332dfc703,
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::store
 * @see app/Http/Controllers/Admin/OrganizationController.php:53
 * @route '/api/admin/organizations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/organizations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::store
 * @see app/Http/Controllers/Admin/OrganizationController.php:53
 * @route '/api/admin/organizations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::store
 * @see app/Http/Controllers/Admin/OrganizationController.php:53
 * @route '/api/admin/organizations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::store
 * @see app/Http/Controllers/Admin/OrganizationController.php:53
 * @route '/api/admin/organizations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::store
 * @see app/Http/Controllers/Admin/OrganizationController.php:53
 * @route '/api/admin/organizations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\OrganizationController::update
 * @see app/Http/Controllers/Admin/OrganizationController.php:75
 * @route '/api/admin/organizations/{organization}'
 */
export const update = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/organizations/{organization}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::update
 * @see app/Http/Controllers/Admin/OrganizationController.php:75
 * @route '/api/admin/organizations/{organization}'
 */
update.url = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { organization: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { organization: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    organization: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        organization: typeof args.organization === 'object'
                ? args.organization.id
                : args.organization,
                }

    return update.definition.url
            .replace('{organization}', parsedArgs.organization.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::update
 * @see app/Http/Controllers/Admin/OrganizationController.php:75
 * @route '/api/admin/organizations/{organization}'
 */
update.put = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::update
 * @see app/Http/Controllers/Admin/OrganizationController.php:75
 * @route '/api/admin/organizations/{organization}'
 */
    const updateForm = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::update
 * @see app/Http/Controllers/Admin/OrganizationController.php:75
 * @route '/api/admin/organizations/{organization}'
 */
        updateForm.put = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\OrganizationController::destroy
 * @see app/Http/Controllers/Admin/OrganizationController.php:90
 * @route '/api/admin/organizations/{organization}'
 */
export const destroy = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/organizations/{organization}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::destroy
 * @see app/Http/Controllers/Admin/OrganizationController.php:90
 * @route '/api/admin/organizations/{organization}'
 */
destroy.url = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { organization: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { organization: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    organization: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        organization: typeof args.organization === 'object'
                ? args.organization.id
                : args.organization,
                }

    return destroy.definition.url
            .replace('{organization}', parsedArgs.organization.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::destroy
 * @see app/Http/Controllers/Admin/OrganizationController.php:90
 * @route '/api/admin/organizations/{organization}'
 */
destroy.delete = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::destroy
 * @see app/Http/Controllers/Admin/OrganizationController.php:90
 * @route '/api/admin/organizations/{organization}'
 */
    const destroyForm = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::destroy
 * @see app/Http/Controllers/Admin/OrganizationController.php:90
 * @route '/api/admin/organizations/{organization}'
 */
        destroyForm.delete = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/organizations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\OrganizationController::create
 * @see app/Http/Controllers/Admin/OrganizationController.php:48
 * @route '/admin/organizations/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
export const edit = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/organizations/{organization}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
edit.url = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { organization: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { organization: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    organization: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        organization: typeof args.organization === 'object'
                ? args.organization.id
                : args.organization,
                }

    return edit.definition.url
            .replace('{organization}', parsedArgs.organization.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
edit.get = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
edit.head = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
    const editForm = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
        editForm.get = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\OrganizationController::edit
 * @see app/Http/Controllers/Admin/OrganizationController.php:68
 * @route '/admin/organizations/{organization}/edit'
 */
        editForm.head = (args: { organization: number | { id: number } } | [organization: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
const OrganizationController = { index, store, update, destroy, create, edit }

export default OrganizationController
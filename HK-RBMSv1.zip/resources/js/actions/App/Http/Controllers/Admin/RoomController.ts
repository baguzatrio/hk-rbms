import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
const index88099f883c765a7112f094e68f0f54e8 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index88099f883c765a7112f094e68f0f54e8.url(options),
    method: 'get',
})

index88099f883c765a7112f094e68f0f54e8.definition = {
    methods: ["get","head"],
    url: '/api/admin/rooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
index88099f883c765a7112f094e68f0f54e8.url = (options?: RouteQueryOptions) => {
    return index88099f883c765a7112f094e68f0f54e8.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
index88099f883c765a7112f094e68f0f54e8.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index88099f883c765a7112f094e68f0f54e8.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
index88099f883c765a7112f094e68f0f54e8.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index88099f883c765a7112f094e68f0f54e8.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
    const index88099f883c765a7112f094e68f0f54e8Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index88099f883c765a7112f094e68f0f54e8.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
        index88099f883c765a7112f094e68f0f54e8Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index88099f883c765a7112f094e68f0f54e8.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/api/admin/rooms'
 */
        index88099f883c765a7112f094e68f0f54e8Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index88099f883c765a7112f094e68f0f54e8.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index88099f883c765a7112f094e68f0f54e8.form = index88099f883c765a7112f094e68f0f54e8Form
    /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
const indexe6f3743b1b569ca0a8d93170d5fb956e = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe6f3743b1b569ca0a8d93170d5fb956e.url(options),
    method: 'get',
})

indexe6f3743b1b569ca0a8d93170d5fb956e.definition = {
    methods: ["get","head"],
    url: '/admin/rooms',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
indexe6f3743b1b569ca0a8d93170d5fb956e.url = (options?: RouteQueryOptions) => {
    return indexe6f3743b1b569ca0a8d93170d5fb956e.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
indexe6f3743b1b569ca0a8d93170d5fb956e.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexe6f3743b1b569ca0a8d93170d5fb956e.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
indexe6f3743b1b569ca0a8d93170d5fb956e.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexe6f3743b1b569ca0a8d93170d5fb956e.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
    const indexe6f3743b1b569ca0a8d93170d5fb956eForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexe6f3743b1b569ca0a8d93170d5fb956e.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
        indexe6f3743b1b569ca0a8d93170d5fb956eForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexe6f3743b1b569ca0a8d93170d5fb956e.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoomController::index
 * @see app/Http/Controllers/Admin/RoomController.php:13
 * @route '/admin/rooms'
 */
        indexe6f3743b1b569ca0a8d93170d5fb956eForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexe6f3743b1b569ca0a8d93170d5fb956e.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexe6f3743b1b569ca0a8d93170d5fb956e.form = indexe6f3743b1b569ca0a8d93170d5fb956eForm

/**
* Multiple routes resolve to \App\Http\Controllers\Admin\RoomController::index, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `index['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const index = {
    '/api/admin/rooms': index88099f883c765a7112f094e68f0f54e8,
    '/admin/rooms': indexe6f3743b1b569ca0a8d93170d5fb956e,
}

/**
* @see \App\Http\Controllers\Admin\RoomController::store
 * @see app/Http/Controllers/Admin/RoomController.php:51
 * @route '/api/admin/rooms'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/rooms',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::store
 * @see app/Http/Controllers/Admin/RoomController.php:51
 * @route '/api/admin/rooms'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::store
 * @see app/Http/Controllers/Admin/RoomController.php:51
 * @route '/api/admin/rooms'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::store
 * @see app/Http/Controllers/Admin/RoomController.php:51
 * @route '/api/admin/rooms'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::store
 * @see app/Http/Controllers/Admin/RoomController.php:51
 * @route '/api/admin/rooms'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\RoomController::update
 * @see app/Http/Controllers/Admin/RoomController.php:85
 * @route '/api/admin/rooms/{room}'
 */
export const update = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/rooms/{room}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::update
 * @see app/Http/Controllers/Admin/RoomController.php:85
 * @route '/api/admin/rooms/{room}'
 */
update.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return update.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::update
 * @see app/Http/Controllers/Admin/RoomController.php:85
 * @route '/api/admin/rooms/{room}'
 */
update.put = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::update
 * @see app/Http/Controllers/Admin/RoomController.php:85
 * @route '/api/admin/rooms/{room}'
 */
    const updateForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::update
 * @see app/Http/Controllers/Admin/RoomController.php:85
 * @route '/api/admin/rooms/{room}'
 */
        updateForm.put = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\RoomController::destroy
 * @see app/Http/Controllers/Admin/RoomController.php:105
 * @route '/api/admin/rooms/{room}'
 */
export const destroy = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/rooms/{room}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::destroy
 * @see app/Http/Controllers/Admin/RoomController.php:105
 * @route '/api/admin/rooms/{room}'
 */
destroy.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return destroy.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::destroy
 * @see app/Http/Controllers/Admin/RoomController.php:105
 * @route '/api/admin/rooms/{room}'
 */
destroy.delete = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::destroy
 * @see app/Http/Controllers/Admin/RoomController.php:105
 * @route '/api/admin/rooms/{room}'
 */
    const destroyForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::destroy
 * @see app/Http/Controllers/Admin/RoomController.php:105
 * @route '/api/admin/rooms/{room}'
 */
        destroyForm.delete = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/rooms/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoomController::create
 * @see app/Http/Controllers/Admin/RoomController.php:46
 * @route '/admin/rooms/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
export const show = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/admin/rooms/{room}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
show.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return show.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
show.get = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
show.head = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
    const showForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
        showForm.get = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoomController::show
 * @see app/Http/Controllers/Admin/RoomController.php:71
 * @route '/admin/rooms/{room}'
 */
        showForm.head = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
export const edit = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/rooms/{room}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
edit.url = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { room: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { room: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    room: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        room: typeof args.room === 'object'
                ? args.room.id
                : args.room,
                }

    return edit.definition.url
            .replace('{room}', parsedArgs.room.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
edit.get = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
edit.head = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
    const editForm = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
        editForm.get = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\RoomController::edit
 * @see app/Http/Controllers/Admin/RoomController.php:78
 * @route '/admin/rooms/{room}/edit'
 */
        editForm.head = (args: { room: number | { id: number } } | [room: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
const RoomController = { index, store, update, destroy, create, show, edit }

export default RoomController
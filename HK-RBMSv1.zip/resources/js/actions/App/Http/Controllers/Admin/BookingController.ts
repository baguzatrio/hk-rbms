import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
const index957b52e86fe5e50e84f9376175eee638 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index957b52e86fe5e50e84f9376175eee638.url(options),
    method: 'get',
})

index957b52e86fe5e50e84f9376175eee638.definition = {
    methods: ["get","head"],
    url: '/api/admin/bookings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
index957b52e86fe5e50e84f9376175eee638.url = (options?: RouteQueryOptions) => {
    return index957b52e86fe5e50e84f9376175eee638.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
index957b52e86fe5e50e84f9376175eee638.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index957b52e86fe5e50e84f9376175eee638.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
index957b52e86fe5e50e84f9376175eee638.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index957b52e86fe5e50e84f9376175eee638.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
    const index957b52e86fe5e50e84f9376175eee638Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index957b52e86fe5e50e84f9376175eee638.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
        index957b52e86fe5e50e84f9376175eee638Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index957b52e86fe5e50e84f9376175eee638.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/api/admin/bookings'
 */
        index957b52e86fe5e50e84f9376175eee638Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index957b52e86fe5e50e84f9376175eee638.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index957b52e86fe5e50e84f9376175eee638.form = index957b52e86fe5e50e84f9376175eee638Form
    /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
const index56fb871e9f6647fbf205b47f4ad20d89 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index56fb871e9f6647fbf205b47f4ad20d89.url(options),
    method: 'get',
})

index56fb871e9f6647fbf205b47f4ad20d89.definition = {
    methods: ["get","head"],
    url: '/admin/bookings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
index56fb871e9f6647fbf205b47f4ad20d89.url = (options?: RouteQueryOptions) => {
    return index56fb871e9f6647fbf205b47f4ad20d89.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
index56fb871e9f6647fbf205b47f4ad20d89.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index56fb871e9f6647fbf205b47f4ad20d89.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
index56fb871e9f6647fbf205b47f4ad20d89.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index56fb871e9f6647fbf205b47f4ad20d89.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
    const index56fb871e9f6647fbf205b47f4ad20d89Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index56fb871e9f6647fbf205b47f4ad20d89.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
        index56fb871e9f6647fbf205b47f4ad20d89Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index56fb871e9f6647fbf205b47f4ad20d89.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::index
 * @see app/Http/Controllers/Admin/BookingController.php:18
 * @route '/admin/bookings'
 */
        index56fb871e9f6647fbf205b47f4ad20d89Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index56fb871e9f6647fbf205b47f4ad20d89.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index56fb871e9f6647fbf205b47f4ad20d89.form = index56fb871e9f6647fbf205b47f4ad20d89Form

/**
* Multiple routes resolve to \App\Http\Controllers\Admin\BookingController::index, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `index['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
export const index = {
    '/api/admin/bookings': index957b52e86fe5e50e84f9376175eee638,
    '/admin/bookings': index56fb871e9f6647fbf205b47f4ad20d89,
}

/**
* @see \App\Http\Controllers\Admin\BookingController::store
 * @see app/Http/Controllers/Admin/BookingController.php:263
 * @route '/api/admin/bookings'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/bookings',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::store
 * @see app/Http/Controllers/Admin/BookingController.php:263
 * @route '/api/admin/bookings'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::store
 * @see app/Http/Controllers/Admin/BookingController.php:263
 * @route '/api/admin/bookings'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::store
 * @see app/Http/Controllers/Admin/BookingController.php:263
 * @route '/api/admin/bookings'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::store
 * @see app/Http/Controllers/Admin/BookingController.php:263
 * @route '/api/admin/bookings'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\BookingController::update
 * @see app/Http/Controllers/Admin/BookingController.php:359
 * @route '/api/admin/bookings/{book}'
 */
export const update = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/bookings/{book}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::update
 * @see app/Http/Controllers/Admin/BookingController.php:359
 * @route '/api/admin/bookings/{book}'
 */
update.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return update.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::update
 * @see app/Http/Controllers/Admin/BookingController.php:359
 * @route '/api/admin/bookings/{book}'
 */
update.put = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::update
 * @see app/Http/Controllers/Admin/BookingController.php:359
 * @route '/api/admin/bookings/{book}'
 */
    const updateForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::update
 * @see app/Http/Controllers/Admin/BookingController.php:359
 * @route '/api/admin/bookings/{book}'
 */
        updateForm.put = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\BookingController::approve
 * @see app/Http/Controllers/Admin/BookingController.php:78
 * @route '/api/admin/bookings/{book}/approve'
 */
export const approve = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

approve.definition = {
    methods: ["post"],
    url: '/api/admin/bookings/{book}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::approve
 * @see app/Http/Controllers/Admin/BookingController.php:78
 * @route '/api/admin/bookings/{book}/approve'
 */
approve.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return approve.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::approve
 * @see app/Http/Controllers/Admin/BookingController.php:78
 * @route '/api/admin/bookings/{book}/approve'
 */
approve.post = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approve.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::approve
 * @see app/Http/Controllers/Admin/BookingController.php:78
 * @route '/api/admin/bookings/{book}/approve'
 */
    const approveForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approve.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::approve
 * @see app/Http/Controllers/Admin/BookingController.php:78
 * @route '/api/admin/bookings/{book}/approve'
 */
        approveForm.post = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approve.url(args, options),
            method: 'post',
        })
    
    approve.form = approveForm
/**
* @see \App\Http\Controllers\Admin\BookingController::reject
 * @see app/Http/Controllers/Admin/BookingController.php:112
 * @route '/api/admin/bookings/{book}/reject'
 */
export const reject = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

reject.definition = {
    methods: ["post"],
    url: '/api/admin/bookings/{book}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::reject
 * @see app/Http/Controllers/Admin/BookingController.php:112
 * @route '/api/admin/bookings/{book}/reject'
 */
reject.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return reject.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::reject
 * @see app/Http/Controllers/Admin/BookingController.php:112
 * @route '/api/admin/bookings/{book}/reject'
 */
reject.post = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: reject.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::reject
 * @see app/Http/Controllers/Admin/BookingController.php:112
 * @route '/api/admin/bookings/{book}/reject'
 */
    const rejectForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: reject.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::reject
 * @see app/Http/Controllers/Admin/BookingController.php:112
 * @route '/api/admin/bookings/{book}/reject'
 */
        rejectForm.post = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: reject.url(args, options),
            method: 'post',
        })
    
    reject.form = rejectForm
/**
* @see \App\Http\Controllers\Admin\BookingController::bulkApprove
 * @see app/Http/Controllers/Admin/BookingController.php:147
 * @route '/api/admin/bookings/bulk-approve'
 */
export const bulkApprove = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkApprove.url(options),
    method: 'post',
})

bulkApprove.definition = {
    methods: ["post"],
    url: '/api/admin/bookings/bulk-approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::bulkApprove
 * @see app/Http/Controllers/Admin/BookingController.php:147
 * @route '/api/admin/bookings/bulk-approve'
 */
bulkApprove.url = (options?: RouteQueryOptions) => {
    return bulkApprove.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::bulkApprove
 * @see app/Http/Controllers/Admin/BookingController.php:147
 * @route '/api/admin/bookings/bulk-approve'
 */
bulkApprove.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkApprove.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::bulkApprove
 * @see app/Http/Controllers/Admin/BookingController.php:147
 * @route '/api/admin/bookings/bulk-approve'
 */
    const bulkApproveForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkApprove.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::bulkApprove
 * @see app/Http/Controllers/Admin/BookingController.php:147
 * @route '/api/admin/bookings/bulk-approve'
 */
        bulkApproveForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkApprove.url(options),
            method: 'post',
        })
    
    bulkApprove.form = bulkApproveForm
/**
* @see \App\Http\Controllers\Admin\BookingController::bulkReject
 * @see app/Http/Controllers/Admin/BookingController.php:196
 * @route '/api/admin/bookings/bulk-reject'
 */
export const bulkReject = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkReject.url(options),
    method: 'post',
})

bulkReject.definition = {
    methods: ["post"],
    url: '/api/admin/bookings/bulk-reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::bulkReject
 * @see app/Http/Controllers/Admin/BookingController.php:196
 * @route '/api/admin/bookings/bulk-reject'
 */
bulkReject.url = (options?: RouteQueryOptions) => {
    return bulkReject.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::bulkReject
 * @see app/Http/Controllers/Admin/BookingController.php:196
 * @route '/api/admin/bookings/bulk-reject'
 */
bulkReject.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: bulkReject.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::bulkReject
 * @see app/Http/Controllers/Admin/BookingController.php:196
 * @route '/api/admin/bookings/bulk-reject'
 */
    const bulkRejectForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: bulkReject.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::bulkReject
 * @see app/Http/Controllers/Admin/BookingController.php:196
 * @route '/api/admin/bookings/bulk-reject'
 */
        bulkRejectForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: bulkReject.url(options),
            method: 'post',
        })
    
    bulkReject.form = bulkRejectForm
/**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
export const show = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/admin/bookings/{book}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
show.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return show.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
show.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
show.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
    const showForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
        showForm.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::show
 * @see app/Http/Controllers/Admin/BookingController.php:223
 * @route '/api/admin/bookings/{book}'
 */
        showForm.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/bookings/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::create
 * @see app/Http/Controllers/Admin/BookingController.php:255
 * @route '/admin/bookings/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
export const edit = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/bookings/{book}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
edit.url = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { book: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { book: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    book: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        book: typeof args.book === 'object'
                ? args.book.id
                : args.book,
                }

    return edit.definition.url
            .replace('{book}', parsedArgs.book.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
edit.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
edit.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
    const editForm = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
        editForm.get = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::edit
 * @see app/Http/Controllers/Admin/BookingController.php:338
 * @route '/admin/bookings/{book}/edit'
 */
        editForm.head = (args: { book: number | { id: number } } | [book: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
export const exportMethod = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})

exportMethod.definition = {
    methods: ["get","head"],
    url: '/admin/bookings/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
exportMethod.url = (options?: RouteQueryOptions) => {
    return exportMethod.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
exportMethod.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportMethod.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
exportMethod.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportMethod.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
    const exportMethodForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportMethod.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
        exportMethodForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\BookingController::exportMethod
 * @see app/Http/Controllers/Admin/BookingController.php:0
 * @route '/admin/bookings/export'
 */
        exportMethodForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportMethod.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportMethod.form = exportMethodForm
const BookingController = { index, store, update, approve, reject, bulkApprove, bulkReject, show, create, edit, exportMethod, export: exportMethod }

export default BookingController
import OrganizationController from './OrganizationController'
import RoomController from './RoomController'
import UserController from './UserController'
import BookingController from './BookingController'
import ActivityLogController from './ActivityLogController'
import RoomDisplayController from './RoomDisplayController'
const Admin = {
    OrganizationController: Object.assign(OrganizationController, OrganizationController),
RoomController: Object.assign(RoomController, RoomController),
UserController: Object.assign(UserController, UserController),
BookingController: Object.assign(BookingController, BookingController),
ActivityLogController: Object.assign(ActivityLogController, ActivityLogController),
RoomDisplayController: Object.assign(RoomDisplayController, RoomDisplayController),
}

export default Admin
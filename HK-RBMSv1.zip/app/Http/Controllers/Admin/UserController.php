<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;
use Inertia\Response;

class UserController extends Controller
{
    public function index(Request $request)
    {
        if ($request->wantsJson()) {
            $search = $request->input('search');
            $perPage = $request->input('per_page', 10);

            if (!in_array($perPage, [10, 20, 30])) {
                $perPage = 10;
            }

            $users = User::with('organization')
                ->when($search, function ($query, $search) {
                    $searchLower = strtolower($search);
                    $query->where(function ($q) use ($searchLower) {
                        $q->whereRaw('LOWER(name) LIKE ?', ["%{$searchLower}%"])
                          ->orWhereRaw('LOWER(email) LIKE ?', ["%{$searchLower}%"])
                          ->orWhereHas('organization', function ($qOrg) use ($searchLower) {
                              $qOrg->whereRaw('LOWER(name) LIKE ?', ["%{$searchLower}%"]);
                          });
                    });
                })
                ->latest()
                ->paginate($perPage)
                ->withQueryString();

            return response()->json([
                'users' => $users,
                'filters' => [
                    'search' => $search,
                    'per_page' => (int) $perPage,
                ],
            ]);
        }

        return Inertia::render('Admin/Users/Index');
    }

    public function create(): Response
    {
        return Inertia::render('Admin/Users/Create', [
            'organizations' => Organization::all()
        ]);
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'name'            => 'required|string|max:255',
            'email'           => 'required|string|email|max:255|unique:users,email',
            'password'        => 'required|string|min:8',
            'role'            => 'required|string|in:admin,user',
            'organization_id' => 'nullable|exists:organizations,id',
        ]);

        $user = User::create([
            'name'            => $validated['name'],
            'email'           => $validated['email'],
            'password'        => Hash::make($validated['password']),
            'role'            => $validated['role'],
            'organization_id' => $validated['organization_id'],
        ]);

        $user->syncRoles([$validated['role']]);

        return response()->json([
            'message' => 'User berhasil dibuat.',
            'data' => $user,
        ], 201);
    }

    public function edit(User $user): Response
    {
        return Inertia::render('Admin/Users/Edit', [
            'user'          => $user->load('roles'),
            'organizations' => Organization::all()
        ]);
    }

    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'name'            => 'required|string|max:255',
            'email'           => 'required|string|email|max:255|unique:users,email,' . $user->id,
            'role'            => 'required|string|in:admin,user',
            'organization_id' => 'nullable|exists:organizations,id',
        ]);

        $user->update([
            'name'            => $validated['name'],
            'email'           => $validated['email'],
            'role'            => $validated['role'],
            'organization_id' => $validated['organization_id'],
        ]);

        $user->syncRoles([$validated['role']]);

        return response()->json([
            'message' => 'User berhasil diupdate.',
            'data' => $user,
        ], 200);
    }

    public function destroy(User $user)
    {
        if (auth()->id() === $user->id) {
            return response()->json([
                'message' => 'Anda tidak bisa menghapus diri sendiri.',
            ], 403);
        }

        $user->delete();

        return response()->json([
            'message' => 'User berhasil dihapus.',
        ], 200);
    }

    public function resetPassword(Request $request, User $user)
    {
        $request->validate([
            'password' => 'required|string|min:8'
        ]);

        $user->update([
            'password' => Hash::make($request->password)
        ]);

        return response()->json([
            'message' => 'Password user berhasil direset.',
        ], 200);
    }

    public function bookings(User $user)
    {
        $bookings = $user->bookings()
            ->with('room')
            ->latest()
            ->get()
            ->map(function ($book) {
                return [
                    'id'          => $book->id,
                    'title'       => $book->title,
                    'room_name'   => $book->room?->name ?? '-',
                    'start_date'  => $book->start_date ? $book->start_date->format('Y-m-d') : '-',
                    'start_hour'  => substr($book->start_hour, 0, 5),
                    'finish_hour' => substr($book->finish_hour, 0, 5),
                    'status'      => $book->status,
                ];
            });

        return response()->json($bookings);
    }
}
